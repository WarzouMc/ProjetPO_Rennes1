package aw.common.weapons;

public enum WeaponsType {
    LIGHT_MACHINE_GUN,
    CANON,
    HEAVY_MACHINE_GUN,
    MISSILE,
    BOMB,
    ;
}
