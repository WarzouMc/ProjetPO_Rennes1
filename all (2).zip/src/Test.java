import librairies.StdDraw;
import nouveaucode.CheminParcouru;

public class Test {

    public static void main(String[] args) {
    	CheminParcouru a=new CheminParcouru(1,1,null,null);
    	System.out.println(a.positionDansChemin(1, 1));
    }

}
