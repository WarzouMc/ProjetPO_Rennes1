package aw.core.component;

public interface Drawable {

    String getImagePath();

}
