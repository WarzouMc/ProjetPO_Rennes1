package aw.common.tile.biome;

import ressources.Chemins;

import java.util.Arrays;

public enum TileBiomeType {

    PROPERTY_HQ("QG", Chemins.FICHIER_QG, true, 10),
    PROPERTY_CITY("Ville", Chemins.FICHIER_VILLE, true, 10),
    PROPERTY_FACTORY("Usine", Chemins.FICHIER_USINE, true, 10),
    PLAIN("Plaine", Chemins.FICHIER_PLAINE, false, 0),
    FOREST("Foret", Chemins.FICHIER_FORET, false, 0),
    MOUNTAIN("Montagne", Chemins.FICHIER_MONTAGNE, false, 0),
    SEA("Eau", Chemins.FICHIER_EAU, false, 0),
    ;

    private final String rawString;
    private final String imageFile;
    private final boolean property;
    private int pc;

    TileBiomeType(String rawString, String imageFile, boolean property, int pc) {
        this.rawString = rawString;
        this.imageFile = imageFile;
        this.property = property;
        this.pc =pc;
    }

    public int getPC() {
		return pc;
	}

	public void setPC(int pc) {
		this.pc = pc;
	}

	public String getRawString() {
        return this.rawString;
    }

    String getImageFile() {
        return this.imageFile;
    }

    public boolean isProperty() {
        return this.property;
    }

    public static TileBiomeType fromString(String biome) {
        return Arrays.stream(values())
                .filter(tileBiomeType -> tileBiomeType.rawString.equalsIgnoreCase(biome))
                .findFirst()
                .orElseThrow();
    }
}
